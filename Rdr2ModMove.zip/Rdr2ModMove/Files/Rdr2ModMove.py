import os.path
import shutil
import configparser
import time

cwd = os.path.dirname(os.path.abspath(__file__))

config = configparser.ConfigParser()

config.read(cwd + '\\Config.ini')
Dir = config.get('directory', 'Dir')

if Dir == 'nil':
    DirectoryAdd = input('Enter the directory of your rdr2 root folder with forward slashes e.g. C:/Users/User/Desktop/Red Dead Redemption 2: ')
    config.set('directory', 'Dir', DirectoryAdd)
    with open(cwd + '\\Config.ini', 'w') as configfile:
        config.write(configfile)
    print('the program will exit in 3 seconds to add the directory to the config file')
    time.sleep(3)
    quit()

Rdr2Dir = os.listdir(Dir)
for file in Rdr2Dir:
    if file == '12on7' or file == 'amd_ags_x64.dll' or file == 'anim_0.rpf' or file == 'appdata0_update.rpf' or file == 'bink2w64.dll' or file == 'common_0.rpf' or file == 'data_0.rpf' or file == 'dinput8.dll' or file == 'dxilconv7.dll' or file == 'ffx_fsr2_api_dx12_x64.dll' or file == 'ffx_fsr2_api_vk_x64.dll' or file == 'ffx_fsr2_api_x64.dll' or file == 'hd_0.rpf' or file == 'installscript.vdf' or file == 'levels_0.rpf' or file == 'levels_1.rpf' or file == 'levels_2.rpf' or file == 'levels_3.rpf' or file == 'levels_4.rpf' or file == 'levels_5.rpf' or file == 'levels_6.rpf' or file == 'levels_7.rpf' or file == 'movies_0.rpf' or file == 'NLog.dll' or file == 'NvLowLatencyVk.dll' or file == 'nvngx_dlss.dll' or file == 'oo2core_5_win64.dll' or file == 'packs_0.rpf' or file == 'packs_1.rpf' or file == 'PlayRDR2.exe' or file == 'RDR2.exe' or file == 'Redistributables' or file == 'rowpack_0.rpf' or file == 'shaders_x64.rpf' or file == 'steam_api64.dll' or file == 'textures_0.rpf' or file == 'textures_1.rpf' or file == 'update_1.rpf' or file == 'update_2.rpf' or file == 'update_3.rpf' or file == 'update_4.rpf' or file == 'x64':
        pass
    else:
        try:
            shutil.move(Dir + '/' + file, cwd + '\\Rdr2Mods')
        except:
            print(file + ' is already in the Rdr2Mods folder please delete one\n' + file + ' has not been moved')

print('mods have been moved to the Rdr2Mods folder')